// 🌐 NetaVerse - Full App JS
// Stable update: keeps the existing UI/CSS and public structure intact.

const data = [
  {name:"Narendra Modi",party:"BJP",state:"UP",constituency:"Varanasi"},
  {name:"Amit Shah",party:"BJP",state:"Gujarat",constituency:"Gandhinagar"},
  {name:"Rajnath Singh",party:"BJP",state:"UP",constituency:"Lucknow"},
  {name:"Nirmala Sitharaman",party:"BJP",state:"Karnataka",constituency:"Rajya Sabha"},
  {name:"Subrahmanyam Jaishankar",party:"BJP",state:"Gujarat",constituency:"Rajya Sabha"},
  {name:"Jyotiraditya Scindia",party:"BJP",state:"MP",constituency:"Rajya Sabha"},
  {name:"Giriraj Singh",party:"BJP",state:"Bihar",constituency:"Begusarai"},
  {name:"Piyush Goyal",party:"BJP",state:"MH",constituency:"Rajya Sabha"},
  {name:"Smriti Irani",party:"BJP",state:"UP",constituency:"Amethi"},
  {name:"Ravi Shankar Prasad",party:"BJP",state:"Bihar",constituency:"Patna Sahib"},

  {name:"Mallikarjun Kharge",party:"INC",state:"Karnataka",constituency:"Rajya Sabha"},
  {name:"Rahul Gandhi",party:"INC",state:"Kerala",constituency:"Wayanad"},
  {name:"Sonia Gandhi",party:"INC",state:"UP",constituency:"Raebareli"},
  {name:"Sharad Pawar",party:"NCP",state:"MH",constituency:"Baramati"},
  {name:"H D Deve Gowda",party:"JDS",state:"Karnataka",constituency:"Hassan"},

  {name:"Yogi Adityanath",party:"BJP",state:"UP",constituency:"Gorakhpur"},
  {name:"Nitish Kumar",party:"JDU",state:"Bihar",constituency:"Nalanda"},
  {name:"Mamata Banerjee",party:"TMC",state:"WB",constituency:"Bhabanipur"},
  {name:"Arvind Kejriwal",party:"AAP",state:"Delhi",constituency:"New Delhi"},
  {name:"Eknath Shinde",party:"Shiv Sena",state:"MH",constituency:"Kopri-Pachpakhadi"},
  {name:"M K Stalin",party:"DMK",state:"TN",constituency:"Kolathur"},
  {name:"Siddaramaiah",party:"INC",state:"Karnataka",constituency:"Varuna"},
  {name:"Pinarayi Vijayan",party:"CPM",state:"Kerala",constituency:"Dharmadam"},
  {name:"Bhagwant Mann",party:"AAP",state:"Punjab",constituency:"Dhuri"},
  {name:"Mohan Yadav",party:"BJP",state:"MP",constituency:"Ujjain South"},
  {name:"Pushkar Singh Dhami",party:"BJP",state:"Uttarakhand",constituency:"Khatima"},
  {name:"Pramod Sawant",party:"BJP",state:"Goa",constituency:"Sanquelim"},
  {name:"Conrad Sangma",party:"NPP",state:"Meghalaya",constituency:"South Tura"},
  {name:"Neiphiu Rio",party:"NDPP",state:"Nagaland",constituency:"Northern Angami"},
  {name:"Zoramthanga",party:"MNF",state:"Mizoram",constituency:"Aizawl East"},
  {name:"Naveen Patnaik",party:"BJD",state:"Odisha",constituency:"Hinjili"},
  {name:"Prem Singh Tamang",party:"SKM",state:"Sikkim",constituency:"Soreng-Chakung"},
  {name:"Manik Saha",party:"BJP",state:"Tripura",constituency:"Town Bardowali"},
  {name:"Pema Khandu",party:"BJP",state:"Arunachal Pradesh",constituency:"Mukto"},
  {name:"Vishnu Deo Sai",party:"BJP",state:"Chhattisgarh",constituency:"Kunkuri"},
  {name:"Bhupendra Patel",party:"BJP",state:"Gujarat",constituency:"Ghatlodia"},
  {name:"Nayab Singh Saini",party:"BJP",state:"Haryana",constituency:"Ladwa"},
  {name:"Sukhvinder Singh Sukhu",party:"INC",state:"Himachal Pradesh",constituency:"Nadaun"},

  {name:"Tejashwi Yadav",party:"RJD",state:"Bihar",constituency:"Raghopur"},
  {name:"Chirag Paswan",party:"LJP",state:"Bihar",constituency:"Hajipur"},
  {name:"Devendra Fadnavis",party:"BJP",state:"MH",constituency:"Nagpur South West"},
  {name:"Uddhav Thackeray",party:"Shiv Sena",state:"MH",constituency:"-"},
  {name:"D K Shivakumar",party:"INC",state:"Karnataka",constituency:"Kanakapura"},
  {name:"N Chandrababu Naidu",party:"TDP",state:"AP",constituency:"Kuppam"},
  {name:"YS Jagan Mohan Reddy",party:"YSRCP",state:"AP",constituency:"Pulivendula"},
  {name:"Himanta Biswa Sarma",party:"BJP",state:"Assam",constituency:"Jalukbari"},

  {name:"Atal Bihari Vajpayee",party:"BJP",state:"UP",constituency:"Lucknow"},
  {name:"Manmohan Singh",party:"INC",state:"Punjab",constituency:"Rajya Sabha"},
  {name:"L K Advani",party:"BJP",state:"Gujarat",constituency:"Gandhinagar"},
  {name:"Mulayam Singh Yadav",party:"SP",state:"UP",constituency:"Mainpuri"},
  {name:"Lalu Prasad Yadav",party:"RJD",state:"Bihar",constituency:"Saran"},
  {name:"Ram Vilas Paswan",party:"LJP",state:"Bihar",constituency:"Hajipur"},
  {name:"Sushma Swaraj",party:"BJP",state:"MP",constituency:"Vidisha"},
  {name:"Sushil Kumar Modi",party:"BJP",state:"Bihar",constituency:"Rajya Sabha"}
];

const container = document.getElementById("candidates");
const searchInput = document.getElementById("search");
const stateFilter = document.getElementById("stateFilter");

const imageCache = new Map();

function escapeHTML(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function wikiName(name) {
  return encodeURIComponent(String(name).trim().replace(/\s+/g, "_"));
}

// ---------------- LOAD STATES ----------------
if (stateFilter) {
  const states = [...new Set(data.map(d => d.state))].sort((a, b) => a.localeCompare(b));
  states.forEach(s => {
    const opt = document.createElement("option");
    opt.value = s;
    opt.textContent = s;
    stateFilter.appendChild(opt);
  });
}

// ---------------- FETCH IMAGE ----------------
async function getImage(name) {
  if (imageCache.has(name)) return imageCache.get(name);

  const fallback = "https://via.placeholder.com/300";
  try {
    const res = await fetch(
      `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(name)}`,
      { headers: { "Accept": "application/json" } }
    );

    if (!res.ok) throw new Error(`Wikipedia API returned ${res.status}`);

    const json = await res.json();
    const image = json.thumbnail?.source || fallback;
    imageCache.set(name, image);
    return image;
  } catch (error) {
    console.warn(`Could not load image for ${name}:`, error);
    imageCache.set(name, fallback);
    return fallback;
  }
}

// ---------------- MODAL ----------------
const modal = document.createElement("div");
modal.id = "wikiModal";
modal.innerHTML = `
  <div class="modal-content">
    <span id="closeBtn">✖</span>
    <iframe id="wikiFrame" title="Wikipedia"></iframe>
  </div>
`;
document.body.appendChild(modal);

modal.style.display = "none";

document.addEventListener("click", (e) => {
  if (e.target.id === "closeBtn" || e.target === modal) {
    modal.style.display = "none";
  }
});

// ---------------- ADR ----------------
function openADR(name) {
  const url = "https://www.google.com/search?q=" +
    encodeURIComponent(name + " myneta affidavit");
  window.open(url, "_blank", "noopener,noreferrer");
}

// ---------------- DISPLAY ----------------
async function displayCandidates(list) {
  if (!container) return;

  if (!list.length) {
    container.innerHTML = "<p>No politicians found for your search/filter.</p>";
    return;
  }

  container.innerHTML = "Loading...";

  const cards = await Promise.all(list.map(async c => {
    const img = await getImage(c.name);
    const safeName = escapeHTML(c.name);
    const safeParty = escapeHTML(c.party);
    const safeState = escapeHTML(c.state);
    const safeConstituency = escapeHTML(c.constituency);

    return `
      <div class="card">
        <img src="${escapeHTML(img)}"
             class="profile"
             alt="${safeName}"
             loading="lazy"
             onerror="this.src='https://via.placeholder.com/300';">
        <h2>${safeName}</h2>
        <p><b>${safeConstituency}</b></p>
        <p>${safeParty} • ${safeState}</p>

        <div class="btn-group">
          <a href="wiki.html?name=${wikiName(c.name)}">Wikipedia</a>
          <button type="button" data-adr="${escapeHTML(c.name)}">ADR</button>
        </div>
      </div>
    `;
  }));

  container.innerHTML = cards.join("");

  container.querySelectorAll("[data-adr]").forEach(button => {
    button.addEventListener("click", () => openADR(button.dataset.adr));
  });
}

// ---------------- FILTER ----------------
function applyFilters() {
  const search = (searchInput?.value || "").trim().toLowerCase();
  const state = stateFilter?.value || "";

  let filtered = data.filter(c =>
    `${c.name} ${c.party} ${c.state} ${c.constituency}`
      .toLowerCase()
      .includes(search)
  );

  if (state) {
    filtered = filtered.filter(c => c.state === state);
  }

  displayCandidates(filtered);
}

// ---------------- EVENTS ----------------
searchInput?.addEventListener("input", applyFilters);
stateFilter?.addEventListener("change", applyFilters);

// ---------------- INIT ----------------
displayCandidates(data);
